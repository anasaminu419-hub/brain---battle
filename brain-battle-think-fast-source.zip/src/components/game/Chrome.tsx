import { Link } from "@tanstack/react-router";
import { Heart, Coins, Flame, Zap, ChevronLeft, WifiOff, Volume2, VolumeX } from "lucide-react";
import { useEffect, useState } from "react";
import {
  levelOf,
  xpForLevel,
  MAX_LIVES,
  setState,
  useGameState,
  type GameState,
} from "@/game/state";
import { setSoundEnabled, sfx, unlockAudio } from "@/game/audio";

export function OfflineBadge() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const set = () => setOnline(navigator.onLine);
    set();
    window.addEventListener("online", set);
    window.addEventListener("offline", set);
    return () => {
      window.removeEventListener("online", set);
      window.removeEventListener("offline", set);
    };
  }, []);
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-wide ${
        online
          ? "border-success/40 bg-success/10 text-success"
          : "border-warning/40 bg-warning/10 text-warning"
      }`}
    >
      {online ? (
        <>
          <span className="h-1.5 w-1.5 rounded-full bg-success" /> Online
        </>
      ) : (
        <>
          <WifiOff className="h-3 w-3" /> Offline
        </>
      )}
    </span>
  );
}

/** Keeps the Web Audio engine in sync with the saved preference. */
export function useSoundSync() {
  const { state, hydrated } = useGameState();
  useEffect(() => {
    if (hydrated) setSoundEnabled(state.settings.sound);
  }, [hydrated, state.settings.sound]);
}

export function SoundToggle({ className = "" }: { className?: string }) {
  const { state } = useGameState();
  const on = state.settings.sound;
  return (
    <button
      type="button"
      aria-label={on ? "Turn sound off" : "Turn sound on"}
      aria-pressed={on}
      onClick={() => {
        unlockAudio();
        const next = !on;
        setSoundEnabled(next);
        setState((s) => ({ ...s, settings: { ...s.settings, sound: next } }));
        if (next) sfx.tap();
      }}
      className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-border bg-surface text-foreground transition-colors hover:bg-secondary ${className}`}
    >
      {on ? (
        <Volume2 className="h-5 w-5 text-primary" />
      ) : (
        <VolumeX className="h-5 w-5 text-muted-foreground" />
      )}
    </button>
  );
}

export function StatBar({ state }: { state: GameState }) {
  const lvl = levelOf(state.xp);
  const cur = state.xp - xpForLevel(lvl);
  const span = Math.max(1, xpForLevel(lvl + 1) - xpForLevel(lvl));
  const pct = Math.min(100, Math.round((cur / span) * 100));

  return (
    <div className="bb-card p-3">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <div className="min-w-0">
          <div className="flex items-baseline gap-2">
            <span className="font-display text-sm font-bold text-foreground">Level {lvl}</span>
            <span className="truncate text-xs text-muted-foreground">
              {cur} / {span} XP
            </span>
          </div>
          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary transition-all duration-500"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-3 text-sm">
          <span className="flex items-center gap-1 font-semibold text-destructive">
            <Heart className="h-4 w-4 fill-current" />
            {state.lives}
            <span className="text-muted-foreground">/{MAX_LIVES}</span>
          </span>
          <span className="flex items-center gap-1 font-semibold text-accent">
            <Coins className="h-4 w-4" />
            {state.coins}
          </span>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
        <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-1 font-medium">
          <Flame className="h-3.5 w-3.5 text-accent" /> {state.streak} day streak
        </span>
        <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-1 font-medium">
          <Zap className="h-3.5 w-3.5 text-primary" /> Best {state.highScore.toLocaleString()}
        </span>
        <OfflineBadge />
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  back = "/",
  right,
}: {
  title: string;
  subtitle?: string;
  back?: string;
  right?: React.ReactNode;
}) {
  return (
    <header className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 py-4">
      <Link
        to={back}
        aria-label="Go back"
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-border bg-surface text-foreground transition-colors hover:bg-secondary"
      >
        <ChevronLeft className="h-5 w-5" />
      </Link>
      <div className="min-w-0">
        <h1 className="truncate font-display text-xl font-bold">{title}</h1>
        {subtitle ? <p className="truncate text-xs text-muted-foreground">{subtitle}</p> : null}
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {right}
        <SoundToggle />
      </div>
    </header>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  useSoundSync();
  return (
    <div className="bb-hero min-h-[100svh] w-full overflow-x-hidden">
      <div className="bb-safe mx-auto w-full max-w-xl landscape:max-w-3xl">{children}</div>
    </div>
  );
}
