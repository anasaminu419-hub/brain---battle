/**
 * Ad placement seams — intentionally inert.
 *
 * The core game never depends on these: every function is a no-op unless a real
 * ad provider (e.g. AdMob via a Capacitor/Cordova plugin in the packaged APK)
 * registers itself at runtime. No IDs, no SDK, no network calls are shipped.
 */

export type AdSlot = "menu-banner" | "results-banner";

export interface AdProvider {
  showBanner?: (slot: AdSlot) => void;
  hideBanner?: (slot: AdSlot) => void;
  showInterstitial?: () => Promise<void>;
  showRewarded?: () => Promise<boolean>; // resolves true when the reward is earned
}

let provider: AdProvider | null = null;

export function registerAdProvider(p: AdProvider) {
  provider = p;
}

export function adsAvailable() {
  return provider !== null;
}

export const ads = {
  showBanner(slot: AdSlot) {
    provider?.showBanner?.(slot);
  },
  hideBanner(slot: AdSlot) {
    provider?.hideBanner?.(slot);
  },
  /** Called only at natural breaks (level complete), never mid-question. */
  async interstitial() {
    if (!provider?.showInterstitial) return;
    try {
      await provider.showInterstitial();
    } catch {
      /* ads must never break gameplay */
    }
  },
  /** Optional extra life. Returns false when unavailable so callers fall back. */
  async rewarded(): Promise<boolean> {
    if (!provider?.showRewarded) return false;
    try {
      return await provider.showRewarded();
    } catch {
      return false;
    }
  },
};
