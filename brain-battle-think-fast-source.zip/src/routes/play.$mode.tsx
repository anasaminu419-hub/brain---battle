import { Outlet, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/play/$mode")({
  component: () => <Outlet />,
});
