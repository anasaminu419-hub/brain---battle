import { createFileRoute } from "@tanstack/react-router";
import { ACHIEVEMENTS, levelOf, useGameState } from "@/game/state";
import { PageHeader, Shell } from "@/components/game/Chrome";

export const Route = createFileRoute("/achievements")({
  head: () => ({
    meta: [
      { title: "Achievements — Brain Battle: Think Fast!" },
      {
        name: "description",
        content: "Track your brain-training badges, streaks, XP and lifetime score.",
      },
      { property: "og:title", content: "Achievements — Brain Battle" },
      {
        property: "og:description",
        content: "Unlock 13 badges by mastering every brain-training mode.",
      },
    ],
  }),
  component: AchievementsPage,
});

function AchievementsPage() {
  const { state } = useGameState();
  const unlocked = ACHIEVEMENTS.filter((a) => state.achievements.includes(a.id));

  return (
    <Shell>
      <PageHeader
        title="Achievements"
        subtitle={`${unlocked.length} of ${ACHIEVEMENTS.length} unlocked`}
      />

      <div className="bb-card mb-4 grid grid-cols-4 gap-2 p-4 text-center">
        {[
          ["Level", levelOf(state.xp)],
          ["XP", state.xp],
          ["Played", state.gamesPlayed],
          ["Best run", state.bestStreak],
        ].map(([label, value]) => (
          <div key={label as string}>
            <div className="font-display text-lg font-bold">{value as number}</div>
            <div className="text-[11px] text-muted-foreground">{label as string}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-2">
        {ACHIEVEMENTS.map((a) => {
          const has = state.achievements.includes(a.id);
          return (
            <div
              key={a.id}
              className={`bb-card flex items-center gap-3 p-3 ${has ? "border-accent/40" : "opacity-60"}`}
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-secondary text-xl">
                {has ? a.icon : "🔒"}
              </span>
              <div className="min-w-0">
                <p className="truncate font-display text-sm font-bold">{a.name}</p>
                <p className="truncate text-xs text-muted-foreground">{a.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </Shell>
  );
}
