import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  Play,
  Trophy,
  Settings as SettingsIcon,
  Gamepad2,
  BarChart3,
  X,
  Download,
} from "lucide-react";
import { getTimerMode, levelOf, useGameState } from "@/game/state";
import { Shell, SoundToggle, StatBar } from "@/components/game/Chrome";
import { Splash, useSplash } from "@/components/game/Splash";
import { TimerModeChips } from "@/components/game/TimerModePicker";
import { sfx, unlockAudio } from "@/game/audio";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Brain Battle: Think Fast! — Offline Brain Training Game" },
      {
        name: "description",
        content:
          "Train your brain offline with 7 fast-paced modes: number sequences, patterns, memory, quick math, odd one out, word scramble and logic puzzles. No timer in Relax Mode.",
      },
      { property: "og:title", content: "Brain Battle: Think Fast!" },
      {
        property: "og:description",
        content:
          "7 offline brain-training modes, 24 levels each. Relax, Challenge, Expert and Extreme timing.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const { state } = useGameState();
  const { show, dismiss } = useSplash();
  const [picking, setPicking] = useState(false);
  const navigate = useNavigate();
  const timer = getTimerMode(state.timerMode);

  if (show) return <Splash onDone={dismiss} />;

  return (
    <Shell>
      <div className="flex items-center justify-between gap-3 py-5">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-primary">
            Offline brain gym
          </p>
          <h1 className="bb-gradient-text font-display text-3xl font-extrabold leading-tight">
            🧠 Brain Battle
          </h1>
          <p className="text-sm text-muted-foreground">Think Fast!</p>
        </div>
        <SoundToggle />
      </div>

      <StatBar state={state} />

      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <Mini label="Level" value={levelOf(state.xp)} />
        <Mini label="Best score" value={state.highScore.toLocaleString()} />
        <Mini label="Day streak" value={state.streak} />
      </div>

      <nav className="mt-5 grid gap-2.5 landscape:grid-cols-2">
        <button
          type="button"
          onClick={() => {
            unlockAudio();
            sfx.tap();
            setPicking(true);
          }}
          className="bb-glow inline-flex min-h-16 items-center justify-center gap-2 rounded-2xl bg-primary font-display text-xl font-extrabold tracking-wide text-primary-foreground transition-transform active:scale-[0.98] landscape:col-span-2"
        >
          <Play className="h-6 w-6 fill-current" /> PLAY
        </button>
        <MenuLink
          to="/modes"
          icon={<Gamepad2 className="h-5 w-5 text-primary" />}
          label="GAME MODES"
          hint={timer.name}
        />
        <MenuLink
          to="/achievements"
          icon={<Trophy className="h-5 w-5 text-accent" />}
          label="ACHIEVEMENTS"
          hint={`${state.achievements.length} unlocked`}
        />
        <MenuLink
          to="/leaderboard"
          icon={<BarChart3 className="h-5 w-5 text-success" />}
          label="HIGH SCORES"
          hint={state.highScore.toLocaleString()}
        />
        <MenuLink
          to="/settings"
          icon={<SettingsIcon className="h-5 w-5 text-muted-foreground" />}
          label="SETTINGS"
          hint={state.settings.sound ? "Sound on" : "Sound off"}
        />
        <a
          href="/brain-battle-source.zip"
          download="brain-battle-think-fast-source.zip"
          onClick={() => {
            unlockAudio();
            sfx.tap();
          }}
          className="bb-card flex min-h-14 items-center gap-3 px-4 transition-transform active:scale-[0.98]"
        >
          <span className="shrink-0">
            <Download className="h-5 w-5 text-primary" />
          </span>
          <span className="min-w-0 flex-1 truncate font-display text-sm font-bold tracking-wide">
            DOWNLOAD PROJECT SOURCE
          </span>
          <span className="shrink-0 truncate text-[11px] text-muted-foreground">ZIP</span>
        </a>
      </nav>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        Fully offline · no account · progress saved on this device
      </p>

      {picking ? (
        <div className="fixed inset-0 z-50 grid place-items-end bg-background/85 p-4 backdrop-blur-sm sm:place-items-center">
          <div className="bb-card animate-pop w-full max-w-sm p-5">
            <div className="mb-3 flex items-start gap-3">
              <div className="min-w-0">
                <h2 className="font-display text-lg font-bold">Choose how you play</h2>
                <p className="text-xs text-muted-foreground">
                  Relax Mode is the default — no timer, no pressure.
                </p>
              </div>
              <button
                onClick={() => setPicking(false)}
                aria-label="Close"
                className="ml-auto grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-border bg-surface-2"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <TimerModeChips value={state.timerMode} />
            <button
              onClick={() => {
                sfx.tap();
                setPicking(false);
                void navigate({ to: "/modes" });
              }}
              className="bb-glow mt-4 inline-flex min-h-14 w-full items-center justify-center gap-2 rounded-xl bg-primary font-display text-base font-bold text-primary-foreground active:scale-[0.98]"
            >
              <Play className="h-5 w-5 fill-current" /> Start with{" "}
              {getTimerMode(state.timerMode).name}
            </button>
          </div>
        </div>
      ) : null}
    </Shell>
  );
}

function Mini({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="bb-card min-w-0 p-2.5">
      <div className="truncate font-display text-base font-bold">{value}</div>
      <div className="truncate text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

function MenuLink({
  to,
  icon,
  label,
  hint,
}: {
  to: string;
  icon: React.ReactNode;
  label: string;
  hint?: string;
}) {
  return (
    <Link
      to={to}
      onClick={() => {
        unlockAudio();
        sfx.tap();
      }}
      className="bb-card flex min-h-14 items-center gap-3 px-4 transition-transform active:scale-[0.98]"
    >
      <span className="shrink-0">{icon}</span>
      <span className="min-w-0 flex-1 truncate font-display text-sm font-bold tracking-wide">
        {label}
      </span>
      {hint ? (
        <span className="shrink-0 truncate text-[11px] text-muted-foreground">{hint}</span>
      ) : null}
    </Link>
  );
}
