import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Home, Heart, Star, Timer, Delete } from "lucide-react";
import { toast } from "sonner";
import {
  QUESTIONS_PER_LEVEL,
  buildLevel,
  getMode,
  levelDifficulty,
  LEVELS_PER_MODE,
  type Question,
} from "@/game/modes";
import { applyDailyStreak, getTimerMode, unlockAchievements, useGameState } from "@/game/state";
import { OfflineBadge, Shell, SoundToggle } from "@/components/game/Chrome";
import { sfx, unlockAudio } from "@/game/audio";

export const Route = createFileRoute("/play/$mode/$level")({
  head: ({ params }) => {
    const m = getMode(params.mode);
    const title = `${m?.name ?? "Play"} · Level ${params.level} — Brain Battle`;
    const desc =
      `Play level ${params.level} of ${m?.name ?? "Brain Battle"} offline. ${m?.tagline ?? ""}`.trim();
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
      ],
    };
  },
  component: GameScreen,
});

type Phase = "show" | "answer" | "done";

function GameScreen() {
  const { mode, level: levelParam } = Route.useParams();
  const level = Math.max(1, Math.min(LEVELS_PER_MODE, Number(levelParam) || 1));
  const meta = getMode(mode);
  const navigate = useNavigate();
  const { state, update, hydrated } = useGameState();

  const [runId, setRunId] = useState(0);
  const questions = useMemo(() => (meta ? buildLevel(meta.id, level) : []), [meta, level, runId]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [combo, setCombo] = useState(0);
  const [phase, setPhase] = useState<Phase>("answer");
  const [paused, setPaused] = useState(false);
  const [feedback, setFeedback] = useState<null | { ok: boolean; text: string }>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [selectedCells, setSelectedCells] = useState<number[]>([]);
  const [typed, setTyped] = useState<number[]>([]);
  const timerMode = getTimerMode(state.timerMode);
  const totalTime = timerMode.seconds; // null in Relax Mode
  const [timeLeft, setTimeLeft] = useState(totalTime ?? 0);
  const [timeUp, setTimeUp] = useState(false);
  const [finished, setFinished] = useState<null | { stars: number; xp: number; coins: number }>(
    null,
  );
  const lockRef = useRef(false);

  const q = questions[idx];
  // One clock for the whole challenge; Relax Mode has none at all.
  const timerOn = totalTime !== null && timeLeft > 0 && !paused && !finished && !timeUp && hydrated;

  const resetQuestion = useCallback((question: Question | undefined) => {
    setPicked(null);
    setSelectedCells([]);
    setTyped([]);
    setFeedback(null);
    lockRef.current = false;
    if (question?.kind === "memory") {
      setPhase("show");
      const ms = 1200 + question.cells.length * 450;
      window.setTimeout(() => setPhase("answer"), ms);
    } else {
      setPhase("answer");
    }
  }, []);

  useEffect(() => {
    resetQuestion(questions[idx]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idx, runId, questions]);

  const finishLevel = useCallback(
    (finalScore: number, finalMistakes: number, correctCount: number) => {
      const stars = finalMistakes === 0 ? 3 : finalMistakes <= 2 ? 2 : 1;
      const xp = 40 + level * 8 + stars * 20;
      const coins = 10 + stars * 5 + level;
      setFinished({ stars, xp, coins });
      sfx.levelUp();
      update((s) => {
        let next = applyDailyStreak({ ...s });
        const p = next.progress[mode as never] as {
          unlocked: number;
          stars: Record<number, number>;
          best: Record<number, number>;
        };
        const updatedProgress = {
          unlocked: Math.max(p.unlocked, Math.min(LEVELS_PER_MODE + 1, level + 1)),
          stars: { ...p.stars, [level]: Math.max(p.stars?.[level] ?? 0, stars) },
          best: { ...p.best, [level]: Math.max(p.best?.[level] ?? 0, finalScore) },
        };
        next = {
          ...next,
          xp: next.xp + xp,
          coins: next.coins + coins,
          totalScore: next.totalScore + finalScore,
          highScore: Math.max(next.highScore, finalScore),
          gamesPlayed: next.gamesPlayed + 1,
          perfectLevels: next.perfectLevels + (finalMistakes === 0 ? 1 : 0),
          correctAnswers: next.correctAnswers + correctCount,
          progress: { ...next.progress, [mode]: updatedProgress },
        };
        const res = unlockAchievements(next);
        res.unlocked.forEach((a) => toast.success(`${a.icon} ${a.name}`, { description: a.desc }));
        return res.state;
      });
    },
    [level, mode, update],
  );

  const advance = useCallback(
    (wasCorrect: boolean, gained: number) => {
      const nextScore = score + gained;
      const nextMistakes = mistakes + (wasCorrect ? 0 : 1);
      setScore(nextScore);
      setMistakes(nextMistakes);
      window.setTimeout(() => {
        if (idx + 1 >= questions.length) {
          const correctCount = QUESTIONS_PER_LEVEL - nextMistakes;
          finishLevel(nextScore, nextMistakes, correctCount);
        } else {
          setIdx((i) => i + 1);
        }
      }, 850);
    },
    [score, mistakes, idx, questions.length, finishLevel],
  );

  const submit = useCallback(
    (correct: boolean, correctText: string) => {
      if (lockRef.current) return;
      lockRef.current = true;
      const speedBonus = totalTime ? Math.round((timeLeft / totalTime) * 40) : 20;
      const comboBonus = correct ? Math.min(50, combo * 10) : 0;
      const gained = correct ? 100 + speedBonus + comboBonus : 0;
      setCombo(correct ? combo + 1 : 0);
      if (correct) {
        update((s) => ({ ...s, bestStreak: Math.max(s.bestStreak, combo + 1) }));
      } else {
        update((s) => ({
          ...s,
          lives: Math.max(0, s.lives - 1),
          livesUpdatedAt: s.livesUpdatedAt || Date.now(),
        }));
      }
      if (correct) sfx.correct();
      else sfx.wrong();
      if (state.settings.haptics && typeof navigator !== "undefined" && navigator.vibrate) {
        navigator.vibrate(correct ? 20 : [30, 40, 30]);
      }
      setFeedback({ ok: correct, text: correct ? `+${gained}` : `Answer: ${correctText}` });
      advance(correct, gained);
    },
    [advance, combo, state.settings.haptics, timeLeft, totalTime, update],
  );

  // sync the clock once the saved timing mode is hydrated from local storage
  useEffect(() => {
    if (!hydrated) return;
    setTimeLeft(totalTime ?? 0);
    setTimeUp(false);
  }, [hydrated, totalTime, runId]);

  // whole-challenge countdown (timed modes only)
  useEffect(() => {
    if (!timerOn) return;
    const t = window.setInterval(() => {
      setTimeLeft((v) => {
        if (v <= 1) {
          window.clearInterval(t);
          setTimeUp(true);
          sfx.gameOver();
          return 0;
        }
        return v - 1;
      });
    }, 1000);
    return () => window.clearInterval(t);
  }, [timerOn]);

  const gameOverRef = useRef(false);
  useEffect(() => {
    if (hydrated && state.lives <= 0 && !gameOverRef.current) {
      gameOverRef.current = true;
      sfx.gameOver();
    }
    if (state.lives > 0) gameOverRef.current = false;
  }, [hydrated, state.lives]);

  const restart = () => {
    setIdx(0);
    setScore(0);
    setMistakes(0);
    setCombo(0);
    setFinished(null);
    setPaused(false);
    setTimeUp(false);
    setTimeLeft(totalTime ?? 0);
    setRunId((r) => r + 1);
  };

  if (!meta) {
    return (
      <Shell>
        <p className="py-10 text-center text-sm text-muted-foreground">Unknown mode.</p>
      </Shell>
    );
  }

  const progressPct = Math.round((idx / questions.length) * 100);
  const outOfLives = hydrated && state.lives <= 0 && !finished;

  return (
    <Shell>
      {/* top bar */}
      <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 py-4">
        <button
          onClick={() => {
            unlockAudio();
            setPaused(true);
          }}
          aria-label="Pause game"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-border bg-surface hover:bg-secondary"
        >
          <Pause className="h-5 w-5" />
        </button>
        <div className="min-w-0">
          <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
            <span className="truncate">
              {meta.name} · Lv {level} · {levelDifficulty(level)}
            </span>
            <span className="shrink-0 font-semibold text-foreground">
              {Math.min(idx + 1, questions.length)}/{questions.length}
            </span>
          </div>
          <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span className="flex items-center gap-1 text-sm font-semibold text-destructive">
            <Heart className="h-4 w-4 fill-current" />
            {state.lives}
          </span>
          <SoundToggle />
        </div>
      </div>

      <div className="mb-3 flex items-center justify-between gap-2 text-xs">
        <span className="rounded-full bg-secondary px-2.5 py-1 font-semibold">Score {score}</span>
        {combo >= 2 ? (
          <span className="rounded-full bg-accent/15 px-2.5 py-1 font-semibold text-accent">
            🔥 {combo} combo
          </span>
        ) : null}
        {totalTime !== null ? (
          <span
            className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 font-semibold ${
              timeLeft <= 10 ? "bg-destructive/15 text-destructive" : "bg-secondary"
            }`}
          >
            <Timer className="h-3.5 w-3.5" />
            {Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, "0")}
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 font-semibold">
            🧘 Relax · no timer
          </span>
        )}
        <OfflineBadge />
      </div>

      {/* question */}
      {q && !finished ? (
        <div key={`${idx}-${runId}`} className="bb-card animate-pop p-5">
          {q.kind === "choice" ? (
            <ChoiceQuestion
              q={q}
              picked={picked}
              setPicked={setPicked}
              submit={submit}
              disabled={!!feedback}
            />
          ) : null}
          {q.kind === "memory" ? (
            <MemoryQuestion
              q={q}
              phase={phase}
              selected={selectedCells}
              setSelected={setSelectedCells}
              submit={submit}
              disabled={!!feedback}
            />
          ) : null}
          {q.kind === "scramble" ? (
            <ScrambleQuestion
              q={q}
              typed={typed}
              setTyped={setTyped}
              submit={submit}
              disabled={!!feedback}
            />
          ) : null}
        </div>
      ) : null}

      {feedback ? (
        <div
          className={`mt-4 rounded-2xl border p-3 text-center font-display font-bold ${
            feedback.ok
              ? "border-success/40 bg-success/10 text-success"
              : "animate-shake border-destructive/40 bg-destructive/10 text-destructive"
          }`}
        >
          {feedback.ok ? "Correct! 🎉 " : "Ohhh, nooo! 😮 "}
          {feedback.text}
        </div>
      ) : null}

      {/* pause sheet */}
      {paused && !finished ? (
        <Overlay title="Paused">
          <div className="grid gap-2">
            <ActionButton
              onClick={() => setPaused(false)}
              icon={<Play className="h-4 w-4" />}
              label="Resume"
              primary
            />
            <ActionButton
              onClick={restart}
              icon={<RotateCcw className="h-4 w-4" />}
              label="Restart level"
            />
            <ActionButton
              onClick={() => navigate({ to: "/play/$mode", params: { mode } })}
              icon={<Home className="h-4 w-4" />}
              label="Quit to levels"
            />
          </div>
        </Overlay>
      ) : null}

      {timeUp && !finished ? (
        <Overlay title="Time's up! ⏰">
          <p className="mb-4 text-center text-sm text-muted-foreground">
            {timerMode.name} gives you {timerMode.seconds} seconds per challenge. Score this run:{" "}
            {score}.
          </p>
          <div className="grid gap-2">
            <ActionButton
              onClick={restart}
              icon={<RotateCcw className="h-4 w-4" />}
              label="Try again"
              primary
            />
            <ActionButton
              onClick={() => navigate({ to: "/play/$mode", params: { mode } })}
              icon={<Home className="h-4 w-4" />}
              label="Level select"
            />
          </div>
        </Overlay>
      ) : null}

      {outOfLives ? (
        <Overlay title="Ohhhhh… Try Another! 😅">
          <p className="mb-4 text-center text-sm text-muted-foreground">
            You're out of lives. Lives refill over time, or spend 50 coins to refill now.
          </p>
          <div className="grid gap-2">
            <ActionButton
              onClick={() =>
                update((s) =>
                  s.coins >= 50
                    ? { ...s, coins: s.coins - 50, lives: 5, livesUpdatedAt: Date.now() }
                    : s,
                )
              }
              icon={<Heart className="h-4 w-4" />}
              label="Refill for 50 coins"
              primary
            />
            <ActionButton
              onClick={() => navigate({ to: "/" })}
              icon={<Home className="h-4 w-4" />}
              label="Back home"
            />
          </div>
        </Overlay>
      ) : null}

      {finished ? (
        <Overlay title="Level complete!">
          <div className="mb-3 flex justify-center gap-2">
            {[1, 2, 3].map((s) => (
              <Star
                key={s}
                className={`h-9 w-9 ${s <= finished.stars ? "animate-pop fill-accent text-accent" : "text-muted-foreground/30"}`}
              />
            ))}
          </div>
          <div className="mb-4 grid grid-cols-3 gap-2 text-center text-sm">
            <Stat label="Score" value={score} />
            <Stat label="XP" value={`+${finished.xp}`} />
            <Stat label="Coins" value={`+${finished.coins}`} />
          </div>
          <div className="grid gap-2">
            {level < LEVELS_PER_MODE ? (
              <ActionButton
                onClick={() => {
                  navigate({
                    to: "/play/$mode/$level",
                    params: { mode, level: String(level + 1) },
                  });
                  restart();
                }}
                icon={<Play className="h-4 w-4" />}
                label="Next level"
                primary
              />
            ) : null}
            <ActionButton
              onClick={restart}
              icon={<RotateCcw className="h-4 w-4" />}
              label="Play again"
            />
            <ActionButton
              onClick={() => navigate({ to: "/play/$mode", params: { mode } })}
              icon={<Home className="h-4 w-4" />}
              label="Level select"
            />
          </div>
        </Overlay>
      ) : null}

      <div className="mt-6 text-center">
        <Link
          to="/play/$mode"
          params={{ mode }}
          className="text-xs text-muted-foreground underline"
        >
          Exit level
        </Link>
      </div>
    </Shell>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl bg-secondary p-2">
      <div className="font-display text-base font-bold">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

function ActionButton({
  onClick,
  icon,
  label,
  primary,
}: {
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  primary?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex min-h-12 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition-transform active:scale-[0.98] ${
        primary
          ? "bg-primary text-primary-foreground bb-glow"
          : "border border-border bg-surface-2 text-foreground hover:bg-secondary"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function Overlay({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background/85 p-4 backdrop-blur-sm">
      <div className="bb-card animate-pop w-full max-w-sm p-6">
        <h2 className="mb-4 text-center font-display text-xl font-bold">{title}</h2>
        {children}
      </div>
    </div>
  );
}

function ChoiceQuestion({
  q,
  picked,
  setPicked,
  submit,
  disabled,
}: {
  q: Extract<Question, { kind: "choice" }>;
  picked: number | null;
  setPicked: (n: number) => void;
  submit: (ok: boolean, text: string) => void;
  disabled: boolean;
}) {
  return (
    <div>
      {q.hint ? (
        <p className="mb-2 text-center text-xs uppercase tracking-widest text-muted-foreground">
          {q.hint}
        </p>
      ) : null}
      <p
        className={`mb-5 text-center font-display font-bold leading-snug ${
          q.big ? "text-2xl tracking-wider" : "text-lg"
        }`}
      >
        {q.prompt}
      </p>
      <div className="grid gap-2 sm:grid-cols-2 landscape:grid-cols-2">
        {q.options.map((opt, i) => {
          const isPicked = picked === i;
          const reveal = disabled && i === q.answer;
          const wrongPick = disabled && isPicked && i !== q.answer;
          return (
            <button
              key={`${opt}-${i}`}
              disabled={disabled}
              onClick={() => {
                setPicked(i);
                submit(i === q.answer, q.options[q.answer]!);
              }}
              className={`min-h-14 rounded-xl border px-4 text-base font-semibold transition-transform active:scale-[0.97] ${
                reveal
                  ? "border-success bg-success/15 text-success"
                  : wrongPick
                    ? "border-destructive bg-destructive/15 text-destructive"
                    : "border-border bg-surface-2 hover:border-primary/60"
              }`}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function MemoryQuestion({
  q,
  phase,
  selected,
  setSelected,
  submit,
  disabled,
}: {
  q: Extract<Question, { kind: "memory" }>;
  phase: Phase;
  selected: number[];
  setSelected: (v: number[]) => void;
  submit: (ok: boolean, text: string) => void;
  disabled: boolean;
}) {
  const showing = phase === "show";
  const toggle = (i: number) => {
    if (showing || disabled) return;
    const next = selected.includes(i) ? selected.filter((c) => c !== i) : [...selected, i];
    setSelected(next);
    if (next.length === q.cells.length) {
      const ok =
        next
          .slice()
          .sort((a, b) => a - b)
          .join(",") === q.cells.join(",");
      submit(ok, "the highlighted tiles");
    }
  };
  return (
    <div>
      <p className="mb-4 text-center font-display text-lg font-bold">
        {showing ? q.prompt : `Tap the ${q.cells.length} tiles you saw`}
      </p>
      <div
        className="mx-auto grid max-w-xs gap-2"
        style={{ gridTemplateColumns: `repeat(${q.size}, minmax(0, 1fr))` }}
      >
        {Array.from({ length: q.size * q.size }, (_, i) => {
          const lit = showing && q.cells.includes(i);
          const chosen = !showing && selected.includes(i);
          const wasRight = disabled && q.cells.includes(i);
          return (
            <button
              key={i}
              aria-label={`Tile ${i + 1}`}
              onClick={() => toggle(i)}
              className={`aspect-square rounded-xl border transition-colors ${
                lit || wasRight
                  ? "border-primary bg-primary"
                  : chosen
                    ? "border-accent bg-accent/40"
                    : "border-border bg-surface-2"
              }`}
            />
          );
        })}
      </div>
      <p className="mt-3 text-center text-xs text-muted-foreground">
        {showing ? "Memorise…" : `${selected.length} / ${q.cells.length} selected`}
      </p>
    </div>
  );
}

function ScrambleQuestion({
  q,
  typed,
  setTyped,
  submit,
  disabled,
}: {
  q: Extract<Question, { kind: "scramble" }>;
  typed: number[];
  setTyped: (v: number[]) => void;
  submit: (ok: boolean, text: string) => void;
  disabled: boolean;
}) {
  const word = typed.map((i) => q.letters[i]!).join("");
  const push = (i: number) => {
    if (disabled || typed.includes(i)) return;
    const next = [...typed, i];
    setTyped(next);
    if (next.length === q.letters.length) {
      const built = next.map((k) => q.letters[k]!).join("");
      submit(built === q.answer, q.answer);
    }
  };
  return (
    <div>
      <p className="mb-1 text-center text-xs uppercase tracking-widest text-muted-foreground">
        {q.prompt}
      </p>
      {q.hint ? (
        <p className="mb-4 text-center text-sm text-muted-foreground">Hint: {q.hint}</p>
      ) : null}
      <div className="mb-5 flex flex-wrap justify-center gap-1.5">
        {Array.from({ length: q.letters.length }, (_, i) => (
          <span
            key={i}
            className="grid h-11 w-9 place-items-center rounded-lg border border-border bg-background font-display text-lg font-bold"
          >
            {word[i] ?? ""}
          </span>
        ))}
      </div>
      <div className="flex flex-wrap justify-center gap-2">
        {q.letters.map((ch, i) => (
          <button
            key={i}
            disabled={disabled || typed.includes(i)}
            onClick={() => push(i)}
            className={`h-12 w-11 rounded-xl border font-display text-lg font-bold transition-transform active:scale-95 ${
              typed.includes(i)
                ? "border-border bg-muted text-muted-foreground opacity-40"
                : "border-border bg-surface-2 hover:border-primary/60"
            }`}
          >
            {ch}
          </button>
        ))}
        <button
          onClick={() => !disabled && setTyped(typed.slice(0, -1))}
          aria-label="Delete last letter"
          className="grid h-12 w-11 place-items-center rounded-xl border border-border bg-surface text-muted-foreground"
        >
          <Delete className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
